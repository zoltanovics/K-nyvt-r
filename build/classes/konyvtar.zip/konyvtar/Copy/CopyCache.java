package konyvtar.Copy;

import konyvtar.Copy.*;
import java.util.List;

public interface CopyCache{
    List<Copy> getDataList();
    void refreshData();
}
