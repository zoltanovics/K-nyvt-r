package konyvtar.Common;

public enum ValidateType {
    DELETE, MODIFY, SAVE;
}
