package konyvtar.Borrow.Exceptions;

public class BorrowNotValidException extends Exception{

    public BorrowNotValidException(String message) {
        super(message);
    }
    
}
