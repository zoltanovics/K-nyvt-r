package konyvtar.Member.Exceptions;

public class MemberNotValidException extends Exception{

    public MemberNotValidException(String message) {
        super(message);
    }
    
}
